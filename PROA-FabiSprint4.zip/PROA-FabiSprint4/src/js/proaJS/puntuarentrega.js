document.addEventListener('DOMContentLoaded', () => {
    const botones = document.querySelectorAll('.boton-revisar');
    const popup = document.getElementById('popup');
    const tituloEl = document.getElementById('popup-titulo');
    const estudianteEl = document.getElementById('popup-estudiante');
    const descargarBtn = document.getElementById('boton-descargar');

    botones.forEach(boton => {
        boton.addEventListener('click', () => {
            const titulo = boton.getAttribute('data-titulo') || 'Tarea';
            const estudiante = boton.getAttribute('data-estudiante') || 'Estudiante';
            const archivo = boton.getAttribute('data-archivo');

            tituloEl.textContent = titulo;
            estudianteEl.textContent = estudiante;

            // Si tienes el archivo, puedes activar descarga
            if (archivo) {
                descargarBtn.onclick = () => window.open(archivo, '_blank');
            }

            popup.classList.remove('oculto');
        });
    });
});

function cerrarPopup() {
    document.getElementById('popup').classList.add('oculto');
}
